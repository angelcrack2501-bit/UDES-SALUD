// MideTuAnillo — Vue 3.4.38 (Options API)
const CLAVE = 'midetuanillo.pxmm';

function leerCalibracion() {
  try { const v = parseFloat(localStorage.getItem(CLAVE)); return v > 0 ? v : null; } catch (e) { return null; }
}

Vue.createApp({
  data() {
    const guardado = leerCalibracion();
    return {
      TALLAS: window.TALLAS,
      vista: guardado ? 'anillo' : 'calibrar',
      titulos: { anillo: 'Mide un anillo que ya tienes', papel: 'Mide tu dedo con papel', tabla: 'Tallas y equivalencias', calibrar: 'Calibra tu pantalla' },
      diametro: 17.2,
      circunferencia: null,
      pxmm: guardado || 96 / 25.4,     // valor por defecto: 96 ppp
      pxmmTemp: guardado || 96 / 25.4,
      calibrado: !!guardado,
      error: '',
    };
  },
  watch: {
    vista() { this.error = ''; },
  },
  computed: {
    talla() { return window.tallaMasCercana(this.diametro); },
  },
  methods: {
    px(mm) { return mm * this.pxmm; },
    cambiar(delta) {
      this.diametro = Math.min(25, Math.max(12, +(this.diametro + delta).toFixed(1)));
    },
    calcularPapel() {
      this.error = '';
      const c = Number(this.circunferencia);
      if (!c || c < 35 || c > 80) { this.error = 'Escribe una medida entre 35 y 80 mm.'; return; }
      this.diametro = +(c / Math.PI).toFixed(1);
    },
    elegir(x) { this.diametro = x.d; this.vista = 'anillo'; },
    guardarCalibracion() {
      this.pxmm = this.pxmmTemp;
      this.calibrado = true;
      try { localStorage.setItem(CLAVE, String(this.pxmm)); } catch (e) { /* modo privado */ }
      this.vista = 'anillo';
    },
  },
}).mount('#app');
