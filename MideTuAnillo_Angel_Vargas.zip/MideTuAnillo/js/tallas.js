// Tabla oficial entregada en clase: "Tallas y equivalencias" (T1–T36)
// d = diámetro interno en mm, usa = talla equivalente en Estados Unidos
window.TALLAS = [
  { t: 1, d: 13.0, usa: '1' },      { t: 2, d: 13.4, usa: '2' },      { t: 3, d: 13.7, usa: '2 ½' },
  { t: 4, d: 14.0, usa: '3' },      { t: 5, d: 14.3, usa: '3 ½' },    { t: 6, d: 14.6, usa: '3 ¾' },
  { t: 7, d: 15.0, usa: '4' },      { t: 8, d: 15.3, usa: '4 ½' },    { t: 9, d: 15.6, usa: '5' },
  { t: 10, d: 15.9, usa: '5 ½' },   { t: 11, d: 16.2, usa: '5 ¾' },   { t: 12, d: 16.5, usa: '6' },
  { t: 13, d: 16.8, usa: '6 ½' },   { t: 14, d: 17.2, usa: '7' },     { t: 15, d: 17.5, usa: '7 ½' },
  { t: 16, d: 17.8, usa: '7 ¾' },   { t: 17, d: 18.1, usa: '8' },     { t: 18, d: 18.4, usa: '8 ½' },
  { t: 19, d: 18.8, usa: '8 ¾' },   { t: 20, d: 19.1, usa: '9' },     { t: 21, d: 19.4, usa: '9 ½' },
  { t: 22, d: 19.7, usa: '10' },    { t: 23, d: 20.0, usa: '10 ½' },  { t: 24, d: 20.3, usa: '10 ¾' },
  { t: 25, d: 20.6, usa: '11' },    { t: 26, d: 21.0, usa: '11 ½' },  { t: 27, d: 21.3, usa: '12' },
  { t: 28, d: 21.6, usa: '12 ½' },  { t: 29, d: 22.0, usa: '12 ¾' },  { t: 30, d: 22.3, usa: '13' },
  { t: 31, d: 22.6, usa: '13 ½' },  { t: 32, d: 22.9, usa: '13 ¾' },  { t: 33, d: 23.2, usa: '14' },
  { t: 34, d: 23.5, usa: '14 ½' },  { t: 35, d: 23.9, usa: '15' },    { t: 36, d: 24.2, usa: '15 ½' },
];

// Devuelve la talla más cercana a un diámetro dado (mm)
window.tallaMasCercana = function (dmm) {
  let mejor = TALLAS[0];
  for (const x of TALLAS) if (Math.abs(x.d - dmm) < Math.abs(mejor.d - dmm)) mejor = x;
  return mejor;
};
